
//  fullName = Nebil Gokdemir
//  studen id = 1635427
//  first assigment
//  Created by nebil on 9/20/20.



// Description : A program to encrypt and decrypt a message using a shift cipher
// The plaintext message must only contain lowercase alpha and digits 0 -9
// command line arguments
// -p theplaintextmessage1 - the plaintext (p) message to be encrypted
// -C 2 qnyujrw2n62vn11jpna - the cipher (C) text to be decrypted
// -k 9 - the key (k) shift value
// -E - the option to encrypt (E)
// -D - the option to decrypt (D)




#include <iostream> // std :: cout , std :: cin , etc.
#include <cstdlib> //C++ version of stdlib .h
#include <cstring> //C++ version of string .h

using namespace ::std;
int main(int argc,  char * argv[]) {
    // insert code here...
    
       char alphabet_digits [] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n',
                                   'o','p','q','r','s','t','u','v','w','x','y','z','0','1',
                                   '2','3','4','5','6','7','8','9'};
    
    
    int index_of_plaintext = 0; // argv index of plaintext
    int index_of_ciphertext = 0; // argv index of ciphertext
   
    bool encrypt = false ; bool decrypt = false ;
    
    int k = 0;
    string message = "";
    // todo : process the command line arguments using a loop
    for (int i = 1; i < argc ; i ++){
    // use strcmp to compare command line switches to argv [i]
    // .... your code goes here
        
        
        
        if(strcmp(argv[i], "-p") == 0) {
            encrypt = true;
            index_of_plaintext = i + 1;
          
            
        }
        else if (strcmp(argv[i], "-C") == 0) {
            
            decrypt = true;
            index_of_ciphertext = i + 1;
        }
        
        else if (strcmp(argv[i], "-k") == 0)  {
            
            int newIndex = i + 1;
            k = atof(argv[newIndex]);
            
        }
        

      
        
    
    }
    
    
    
    // todo : -E encrypt the plaintext with key value k
    if(encrypt){
    // use a nested loop to search and replace plaintext with shifted text
    // .... your code goes here
        
       
        for(int j = 0; j < strlen(argv[index_of_plaintext]); j++) {

        for(int i = 0; i < strlen(alphabet_digits); i++) {
             
           

                 
               // string plain_text   (argv[index_of_plaintext]);
                   
               //  char* c = const_cast<char*>(plain_text.c_str());
                 
            char* c  = (argv[index_of_plaintext]);
         
                // cout << c[j] << endl;
            
                 
                 
                 if(alphabet_digits[i] == c[j] ) {
                  
                     int newIndex = (i + k) % 36;
                     
                     message += alphabet_digits[newIndex];
                     
                 }
                 

             
         
                     
                     }


    }
        }
      
        
    // todo : -D decrypt the ciphertext -C with key value k
    if(decrypt){
    // use a nested loop to search and replace ciphertext with plaintext
    // .... your code goes here
        
        
     
        
        
             
             for(int j = 0; j < strlen(argv[index_of_ciphertext]); j++) {
                 
                  for(int i = 0; i < strlen(alphabet_digits); i++) {
                 
                      //string cipher_text = argv[index_of_ciphertext];
                   
                 //char* c = const_cast<char*>(cipher_text.c_str());
                 
                 
                   char* c  = (argv[index_of_ciphertext]);
                 
                // cout << "my string is "<< cipher_text << endl;
        
                 
                 
                 if(alphabet_digits[i] == c[j]) {
                 
                     int newIndex = 0;
                     
                     if((i -k) >= 0) {
                         
                        newIndex = (i - k) % 36 ;

                     }
                     else if((i -k ) < 0 ) {
                      
                          newIndex = ((i - k) % 36) + 36 ;
                     }
                 
                     
                
                     
                    
                     message += alphabet_digits[newIndex];
                    
                     
                 }
                 
                 
             }
             
         }
        
     
    }
    
    
    
    
    
       cout << "message " << message << endl;
     char  xx;
    cout << "Please type one char to exit"<< endl;
    cin >> xx ;
    
    
    return 0;

    



    
    
}
