// Name :  Nebil Gokdemir
// SSID : 1635427
// Assignment : 3
// Submission Date : 11/8/2020

/*
 
 this program accept command line arguments to allow the user to
 enter in a key value k, a plaintext string of characters just described (−p) or a ciphertext (−C) and
 exactly one of the options to encrypt (−E) or decrypt (−D), so base on those input program will print new encrypt or decrypt.
 also message lenght will write on first pixel and shift will write on second pixel on ppm format
 and message index will write on another pixel to able to use i use bitwise and dynamic array.

 
 */


#include <iostream>
#include <cstdlib> 
#include <cstring>  
#include <string>    //C++  string  class
#include <fstream>   //C++ file I/O
#define CBL 64




void print_binary (uint8_t x) 
{
  for(uint8_t mask=0x80; mask!=0; mask>>=1)
  {
    if(x & mask)
    {
      printf("1");
    }
    else
    {
      printf("0");
    }
  }
  printf("\n");
}



// A2  prototypes: encrypt (. . .), decrypt (. . .), etc.
void  encrypt(std:: string& plaintext , int k);
void  decrypt(std:: string& ciphertext , int k);

//  Optional  A3: typedef  can  use  uint8_t  too or any  byte type

typedef  unsigned  char  uchar;

//Todo A3: Part I
void  write_ppm_img( uchar*   image , std:: string  filename , int   w, int   h );
void  read_ppm_img ( uchar* &image , std:: string  filename , int &w, int &h );

//Todo A3: Part II
int  get_index(char c);
void  write_stego_img( uchar* img , int   k, int w, int h, std:: string  msg );
void  read_stego_img ( uchar* img , int& k, int w, int h);


char  codebook [] ={'a','A','b','B','c','C','d','D','e','E','f','F','g','G',
'h','H','i','I','j','J','k','K','l','L','m','M','n','N','o','O','p',
'P','q','Q','r','R','s','S','t','T','u','U','v','V','w','W','x','X','y','Y',
'z','Z','0','1','2','3','4','5','6','7','8','9',',',' '};


using namespace::std; 
string  msg;  //  string  to hold  the  plaintext  or  ciphertext;
string message = "";
int  main(int argc , char *argv []){


//  Example  variables  for  A02
int k = 0;           // k shift
int  msg_index = 0;       //  msg_index  of  plaintext  or  ciphertext  in argv
  
bool  do_encrypt = false;   //True  for  encrypt  or False  for  decrypt
string f = "";


  

    // Get data from terminal

   for (int i = 1; i < argc ; i ++){
  
          if(strcmp(argv[i], "-p") == 0) {
            do_encrypt = true;
            msg_index = i + 1;
            msg = argv[msg_index];
          
            
        }
        else if (strcmp(argv[i], "-D") == 0) {
           
           
            do_encrypt = false;
            
        }
        
        else if (strcmp(argv[i], "-k") == 0)  {
            
            int newIndex = i + 1;
            k = atof(argv[newIndex]);
            
        }
        else if (strcmp(argv[i], "-f") == 0)  { 

             int newIndex = i + 1;
             f = argv[newIndex];

        }



        }



string s = f;
string delimiter = "_";
string token = s.substr(0, s.find(delimiter)); 
string converFileName = s.erase(0, s.find(delimiter) + delimiter.length());





uchar * img = nullptr;
int w = 0, h = 0;   
   //img  width & height



  // read_ppm_img(img , f, &w, &h);

if(do_encrypt) {
read_ppm_img (img , f,  w, h);



}
else {

 read_ppm_img (img ,"crypto_"+ converFileName,  w, h);
 



}





 
   if (do_encrypt) {
       // A2  encrypt  function  unchanged
       //cout<< "msg is " << msg << endl;
           encrypt(msg , k);

         //    cout<< "msg is " << msg << endl;
       // A3 Part II - write_stego  using  ciphertext  msg
           write_stego_img(img , k, w, h, msg);
       // A3: Part I-write_ppm_image 
            write_ppm_img(img , f, w, h);
 
            cout << "Encryption complete"<< endl;
       
       
       }
       //Todo A3: extract  message  from  image  and  decrypt
       else{
           // need to read k and  message  length  then  decrypt
           //  calls A2  decrypt ()  unchanged
           // and  prints  out  the  encrypted  and  decrypted  message
   //write_stego_img(img , k, w, h, msg);

       // write_stego_img(img , k, w, h, msg);
      read_stego_img(img , k, w, h);
           


           }
   //Todo A3: Recover  Allocated  img  Memory
 
 

 
 
   if (img)
        delete [] img;

   std::cout  << "enter  any  key to exit";
   char  exit; std::cin  >> exit;






    return 0;
}






string localMessage = "";

void  read_stego_img ( uchar* img , int& k, int w, int h) {
int imgSize = h * w * 3; 

uchar messageLength = 0;
int intMessageLenght = 0;
uchar shift = 0;
uchar mask = 3;




for (int i = 0; i < imgSize; i++)
{



if(i == 0) {

messageLength = (messageLength |(img[i+2] & mask)) << 4;  //|(img(i + 1))
messageLength = messageLength | (img[i+1]& mask) <<2;
messageLength = messageLength |(img[i] & mask);
intMessageLenght = 3 * ((int) messageLength) + 6 ;


i = 3;

}

if(i == 3) {


shift = (shift |(img[i+2] & mask)) << 4;  //|(img(i + 1))
shift = shift | (img[i+1]& mask) <<2;
shift = shift |(img[i] & mask);

i = 6;

}


while( i < intMessageLenght ) {

uchar number = 0 ;






number = (number |(img[i+2] & mask)) << 4;  //|(img(i + 1))


number = number | (img[i+1]& mask) <<2;

number = number |(img[i] & mask);




localMessage = localMessage + codebook[(int)number];






i = 3 + i;

}

  
}


cout << "the encrypted text was: " << localMessage << endl;

decrypt(localMessage,(int)shift);
//cout << "shift is "<<(int)shift << endl;

cout <<  "the ecrypted message is: " << localMessage << endl;




}










void  write_stego_img( uchar* img , int   k, int w, int h, std:: string  msg ){

int messageLength = msg.length();
int indextSize = h * w * 3; 
 int j = 0;
int intMessageLenght = 3 * msg.length() + 6 ;


for (int i = 0; i < indextSize; i++)
{

 uchar m1 = 3;
 uchar length = (uchar) messageLength;
 uchar shift = (uchar) k; 

if(i == 0) {


uchar temp1 = (length & m1);
img[i] = temp1 | (img[i] << 2 & img[i]); 


}else if(i == 1) {


 uchar temp1 = ((length>>2) & m1);
 img[i] = temp1 | (img[i] << 2 & img[i]); 


}
else if(i == 2) {

 uchar temp1 = ((length>>4) & m1);
 img[i] = temp1 | (img[i] << 2 & img[i]); 

}
else if(i == 3) {

uchar temp1 = ((shift) & m1);
img[i] = temp1 | (img[i] << 2 & img[i]); 
}
else if(i == 4) {
uchar temp1 = ((shift >> 2) & m1);

img[i] = temp1 | (img[i] << 2 & img[i]); 

}
else if(i == 5) {

uchar temp1 = ((shift >> 4) & m1);
img[i] = temp1 | (img[i] << 2 & img[i]); 

}


if(i > 5) {



while(i < intMessageLenght ) {

uchar indexNumber =  uchar(get_index(msg[j]));
uchar temp1 = ((indexNumber) & m1);
img[i] = temp1 | (img[i] << 2 & img[i]); 


  temp1 = ((indexNumber >> 2) & m1);
  img[i+1] = temp1 | (img[i+1] << 2 & img[i]); 



  temp1 = ((indexNumber >> 4) & m1);
  img[i+2] = temp1 | (img[i+2] << 2 & img[i]); 


i = i +3;
j = j + 1;


}



}
}
}








void  read_ppm_img ( uchar* &image , std:: string  filename , int &w, int &h ) {


string format; 
int n ;

ifstream readImage; 
readImage.open(filename); 
if(readImage.is_open()) {

readImage >> format;
readImage >> h; 
readImage >> w;
readImage >>n;

//cout << "THIS IS FROM READ" << h << " w " << w << endl;


int indexSize = h * w * 3;
string newFormat = (string)format;


//image = new unsigned  char[h * w *3];
//uchar * img = nullptr;
image = new  uchar [indexSize];
int temp ;
                                                      

for (int i = 0; i < (indexSize); i++)
{
                                                   
    readImage >> temp;
    uchar c = (uchar)temp;
    image[i] = c;     

}

  


}
readImage.close(); 

}


void  write_ppm_img( uchar*   image , std:: string  filename , int   w, int   h ){



 ofstream writeImage;
 writeImage.open("crypto_"+ filename); 

int indexSize = h * w * 3;

 if(writeImage.is_open()) {

   writeImage <<"P3"<< endl;
   writeImage<< w << " " << h << endl;
   writeImage << 255 <<endl;




  for (int i = 0; i <indexSize; i++)
  {


     uchar temp = image[i];
     int data = (int) temp; 
     writeImage << data <<" ";


  }
  
 }
 //cout <<"image saved to : " <<"crypto_"+ filename <<endl; 

   writeImage.close(); 

}


void encrypt (std :: string & plaintext , int k ) {
      message = "";
    
    for(int i = 0; i < plaintext.size(); i++) {
    
        

        for(int j = 0; j < CBL; j++) {
        
            if(plaintext[i] == codebook[j]){
                
                
                int newIndex = (j + k) % CBL;
                
                
                message += codebook[newIndex];
                
                
            }
            
            }
    }
    
  plaintext = message;
//     cout << " NOOO decrypt " << message; 
}

void decrypt ( std :: string & ciphertext , int k ) {
    
    message = "";
    
    for(int i = 0; i < ciphertext.size(); i++) {
    
        

        for(int j = 0; j < CBL; j++) {
            
        
            if(ciphertext[i] == codebook[j]){
                
                int newIndex = 0;
                
                if((j- k) >= 0) {
                    
                    newIndex = (j-k) % CBL;
                }
                
                else if((j -k ) < 0 ) {
                 
                     newIndex = ((j - k) % CBL) + CBL ;
                }
                message += codebook[newIndex];
                
            
            }
            
            }
        
        }
     // cout << "YESSS decrypt " << message; 

    ciphertext = message;

    }






int  get_index(char c) {
int index = -1;

for (int i = 0; i < CBL; i++)
{
  if (codebook[i] == c) {
   index = i ;
  }
   }

return index;

}